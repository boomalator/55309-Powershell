﻿notepad C:\Windows\System32\WindowsPowerShell\v1.0\DotNetTypes.format.ps1xml

