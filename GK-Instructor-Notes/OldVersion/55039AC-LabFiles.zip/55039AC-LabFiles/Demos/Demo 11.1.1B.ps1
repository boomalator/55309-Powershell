﻿Get-InfoNIC -ComputerName localhost
Get-IngoOS -ComputerName localhost