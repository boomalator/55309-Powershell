﻿function Get-ComputerNamesFromXML {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,
                   ValueFromPipeline=$True,
                   ParameterSetName='Text')]
        [string[]]$InputText,

        [Parameter(ParameterSetName='File')]
        [string]$Filename
    )
    BEGIN {
        $content = ''
    }
    PROCESS {
        $content += $InputText
    }
    END {
        if ($PSBoundParameters.ContainsKey('InputText')) {
            [xml]$xml = $content
        } else {
            [xml]$xml = Get-Content $filename
        }
        foreach ($computer in $xml.computers.computer) {
            $prop = @{'ComputerName'=$computer.name}
            New-Object -TypeName PSObject -Property $prop
        }
    }
} 

function Set-OSVersionInXML {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,
                   ValueFromPipeline=$True)]
        [objectgc ]$SystemInfoObject,

        [Parameter(Mandatory=$True)]
        [string]$InputXMLFile,

        [Parameter(Mandatory=$True)]
        [string]$OutputXMLFile,

        [switch]$PassThru
    )
    PROCESS {
        foreach ($obj in $SystemInfoObject) {
            # get input XML
            [xml]$xml = Get-Content $InputXMLFile

            # find this computer's node
            $computer  = $xml.SelectSingleNode(
                         "//computer[@name='$($obj.computername)']")

            # add the info
            $computer.osversion = $obj.osversion

            # save modified XML
            $xml.Save($OutputXMLFile)

            # write original input object to pipeline
            if ($PassThru) {
                Write-Output $obj
            }
        }
    }
} 

# Assumes you have the MyTools module
# from Chapter 11 installed in the 
# My Documents\WindowsPowerShell\Modules\MyTools folder.

# Demo A
Get-ComputerNamesFromXML -Filename C:\computers.xml |
Get-OSInfo |
Set-OSVersionInXML -input C:\computers.xml -output C:\computers2.xml 


# Demo B
Get-ComputerNamesFromXML -Filename C:\computers.xml |
Get-OSInfo |
Set-OSVersionInXML -input C:\computers.xml -output C:\computers2.xml –passthru |
Set-BIOSVersionInXML –input C:\Computers.xml –output c:\computers3.xml


