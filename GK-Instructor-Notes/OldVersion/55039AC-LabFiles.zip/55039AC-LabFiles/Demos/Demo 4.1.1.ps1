﻿# Continue - the default
$ErrorActionPreference = 'Continue'
Get-WmiObject -Class Win32_BIOS -ComputerName localhost,NONAME,DC

# SilentlyContinue
$ErrorActionPreference = 'SilentlyContinue'
Get-WmiObject -Class Win32_BIOS -ComputerName localhost,NONAME,DC

# Inquire
$ErrorActionPreference = 'Inquire'
Get-WmiObject -Class Win32_BIOS -ComputerName localhost,NONAME,DC

# Stop - note that it never tries DC
$ErrorActionPreference = 'Stop'
Get-WmiObject -Class Win32_BIOS -ComputerName localhost,NONAME,DC
