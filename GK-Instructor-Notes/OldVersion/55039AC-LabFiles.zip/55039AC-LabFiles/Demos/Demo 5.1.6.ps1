﻿# create a CSV
"Hostname" | Out-File c:\hosts.csv
"DC" | Out-File c:\hosts.csv -append
"MEMBER" | Out-File c:\hosts.csv -append

# test it
Import-CSV c:\hosts.csv

# a hostname property is useless - we need a flat-out string
Import-CSV c:\hosts.csv | Select -Property hostname

# that wasn't a string; it was an object with just a hostname property
Import-CSV c:\hosts.csv | Select -ExpandProperty hostname

# that was a plain string
Get-Process -ComputerName (Import-CSV c:\hosts.csv | Select -Expand hostname)