﻿Get-WmiObject -Class Win32_BIOS -ComputerName localhost,NONAME,DC -EA SilentlyContinue

Get-WmiObject -Class Win32_BIOS -ComputerName localhost,NONAME,DC -EA Stop

