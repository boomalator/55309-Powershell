﻿# Create a CSV file
"Name,Value" | Out-File C:\Demo.csv
"D,Get-ChildItem" | Out-File C:\Demo.csv -Append
"S,Get-Service" | Out-File C:\Demo.csv -Append

# Check it
Import-CSV c:\Demo.csv

# use it
Import-CSV C:\Demo.csv | New-Alias

# use the new aliases
D
S
