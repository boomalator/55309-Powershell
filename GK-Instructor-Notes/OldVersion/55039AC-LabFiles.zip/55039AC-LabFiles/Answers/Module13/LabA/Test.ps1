
# Assumes you created C:\TestData.xml as directed

Get-ComputerNamesFromXML �FileName C:\TestData.xml |
Get-OSInfo |
Set-XMLFileData �FileName C:\TestData.xml
