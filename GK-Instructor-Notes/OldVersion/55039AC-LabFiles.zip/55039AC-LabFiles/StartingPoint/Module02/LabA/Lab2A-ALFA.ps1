﻿Get-WmiObject –Class Win32_OperatingSystem –ComputerName CLIENT | 
  Select-Object Version,ServicePackMajorVersion,BuildNumber,OSArchitecture 
