﻿Get-WmiObject –Class Win32_LogicalDisk –Filter "DriveType=3" –Computer CLIENT |
  Where-Object { $_.FreeSpace / $_.Size * 100 –lt 10 } 
